SMODS.Joker{ --sillymoons
    name = "sillymoons",
    key = "sillymoons",
    config = {
        extra = {
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'sillymoons',
        ['text'] = {
            [1] = 'scored cards has a {C:green}#2# in #1#{} chance to create a random {C:planet}planet{} card'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 6,
        y = 1
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {G.GAME.probabilities.normal, card.ability.extra.odds}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if true then
                if pseudorandom('group_0_d02649d3') < G.GAME.probabilities.normal / card.ability.extra.odds then
                        local created_planet = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_planet = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local planet_card = create_card('Planet', G.consumeables, nil, nil, nil, nil, nil, 'joker_forge_planet')
                            planet_card:add_to_deck()
                            G.consumeables:emplace(planet_card)
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_planet and localize('k_plus_planet') or nil, colour = G.C.SECONDARY_SET.Planet})
                    end
            end
        end
    end
}