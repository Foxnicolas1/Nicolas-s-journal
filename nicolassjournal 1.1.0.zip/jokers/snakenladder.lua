SMODS.Joker{ --snake N ladder
    name = "snake N ladder",
    key = "snakenladder",
    config = {
        extra = {
            slyness = 10
        }
    },
    loc_txt = {
        ['name'] = 'snake N ladder',
        ['text'] = {
            [1] = 'grants {C:blue}+10{} Chips per {C:spectral}sly joker{} sold',
            [2] = '(currently {C:blue}+#1#{} Chip)'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.slyness}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    chips = card.ability.extra.slyness
                }
        end
        if context.selling_card and not context.blueprint then
            if (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_sly_joker" then
              return true
          end
      end
      return false
  end)() then
                return {
                    func = function()
                    card.ability.extra.slyness = (card.ability.extra.slyness) + 10
                    return true
                end
                }
            end
        end
    end
}