SMODS.Joker{ --dualized joker
    name = "dualized joker",
    key = "dualizedjoker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'dualized joker',
        ['text'] = {
            [1] = '{C:diamonds}diamonds{} now also counts as {C:clubs}clubs{} and {C:hearts}hearts{} also counts as {C:spades}spades{}',
            [2] = 'also the same when opposite'
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Combine suits effect enabled
        -- Combine suits effect enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine suits effect disabled
        -- Combine suits effect disabled
    end
}