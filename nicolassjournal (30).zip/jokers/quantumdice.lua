SMODS.Joker{ --quantum dice
    name = "quantum dice",
    key = "quantumdice",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'quantum dice',
        ['text'] = {
            [1] = 'quadruples all probabilities',
            [2] = '(example {C:green}1 in 4{} chance into {C:green}4 in 4{} chance)'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    add_to_deck = function(self, card, from_debuff)
        for k, v in pairs(G.GAME.probabilities) do
        G.GAME.probabilities[k] = v * 2
    end
        for k, v in pairs(G.GAME.probabilities) do
        G.GAME.probabilities[k] = v * 2
    end
    end,

    remove_from_deck = function(self, card, from_debuff)
        for k, v in pairs(G.GAME.probabilities) do
        G.GAME.probabilities[k] = v / 2
    end
        for k, v in pairs(G.GAME.probabilities) do
        G.GAME.probabilities[k] = v / 2
    end
    end
}