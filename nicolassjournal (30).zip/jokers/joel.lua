SMODS.Joker{ --joel
    name = "joel",
    key = "joel",
    config = {
        extra = {
            joel = 10
        }
    },
    loc_txt = {
        ['name'] = 'joel',
        ['text'] = {
            [1] = 'gives {C:chips}+10{} when hand is played, doubles when any card is scored',
            [2] = '(currently {C:blue}+#1#{} chip)'
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    cost = 8,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 8,
        y = 2
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.joel}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    chips = card.ability.extra.joel
                }
        end
        if context.individual and context.cardarea == G.play and not context.blueprint then
                card.ability.extra.joel = (card.ability.extra.joel) * 2
        end
    end
}