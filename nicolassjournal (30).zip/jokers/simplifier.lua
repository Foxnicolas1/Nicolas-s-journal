SMODS.Joker{ --simplifier
    name = "simplifier",
    key = "simplifier",
    config = {
        extra = {
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'simplifier',
        ['text'] = {
            [1] = 'discarding a card has a {C:green}#2# to #1#{} chance to turn it into a {C:attention}2{}'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {G.GAME.probabilities.normal, card.ability.extra.odds}}
    end,

    calculate = function(self, card, context)
        if context.discard and not context.blueprint then
            if true then
                if pseudorandom('group_0_1c7251a4') < G.GAME.probabilities.normal / card.ability.extra.odds then
                        SMODS.calculate_effect({func = function()
                assert(SMODS.change_base(context.other_card, nil, "2"))
                    end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "converted", colour = G.C.BLUE})
                    end
            end
        end
    end
}