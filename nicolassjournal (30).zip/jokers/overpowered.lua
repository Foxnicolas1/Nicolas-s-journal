SMODS.Joker{ --overpowered
    name = "overpowered",
    key = "overpowered",
    config = {
        extra = {
            odds = 2,
            odds2 = 4,
            chips = 60,
            mult = 4
        }
    },
    loc_txt = {
        ['name'] = 'overpowered',
        ['text'] = {
            [1] = 'gives {C:blue}+60 chips{} or {C:red}+4 mult{} while scoring a 6, 7, 8, 9 or 10'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if (context.other_card:get_id() == 6 or context.other_card:get_id() == 7 or context.other_card:get_id() == 8 or context.other_card:get_id() == 9 or context.other_card:get_id() == 10) then
                if pseudorandom('group_0_e74a9e3f') < G.GAME.probabilities.normal / card.ability.extra.odds then
                        SMODS.calculate_effect({chips = card.ability.extra.chips}, card)
                    end
                if pseudorandom('group_1_22067a3b') < G.GAME.probabilities.normal / card.ability.extra.odds2 then
                        SMODS.calculate_effect({mult = card.ability.extra.mult}, card)
                    end
            end
        end
    end
}