SMODS.Joker{ --foxnicolas1 (enraged)
    name = "foxnicolas1 (enraged)",
    key = "foxnicolas1enraged",
    config = {
        extra = {
            currentmoney = 1
        }
    },
    loc_txt = {
        ['name'] = 'foxnicolas1 (enraged)',
        ['text'] = {
            [1] = 'gain {X:mult,C:white}^mult{} x10 depending on how much money you have',
            [2] = '(currently {X:mult,C:white}^#1#{} mult)'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    cost = 25,
    rarity = "nicolass_mythical",
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 2,
        y = 4
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.currentmoney + ((G.GAME.dollars or 0)) * 0.1}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    e_mult = card.ability.extra.currentmoney + (G.GAME.dollars) * 0.1,
                    extra = {
                        message = "wealth is key to me",
                        colour = G.C.WHITE
                        }
                }
        end
    end
}