SMODS.Joker{ --godly cat
    name = "godly cat",
    key = "godlycat",
    config = {
        extra = {
            godly = 1
        }
    },
    loc_txt = {
        ['name'] = 'godly cat',
        ['text'] = {
            [1] = 'gains {X:mult,C:white}^0.25{} Mult when {C:attention}Lucky{} successfullly triggers',
            [2] = 'also doubles all probabilities'
        }
    },
    pos = {
        x = 3,
        y = 4
    },
    cost = 4,
    rarity = "nicolass_mythical",
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main then
                return {
                    e_mult = card.ability.extra.godly
                }
        end
        if context.individual and context.cardarea == G.play and not context.blueprint then
            if context.other_card.lucky_trigger then
                card.ability.extra.godly = (card.ability.extra.godly) + 0.25
                return {
                    message = "upgraded"
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        for k, v in pairs(G.GAME.probabilities) do
        G.GAME.probabilities[k] = v * 2
    end
    end,

    remove_from_deck = function(self, card, from_debuff)
        for k, v in pairs(G.GAME.probabilities) do
        G.GAME.probabilities[k] = v / 2
    end
    end
}