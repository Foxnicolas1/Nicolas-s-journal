SMODS.Joker{ --john
    name = "john",
    key = "john",
    config = {
        extra = {
            currentmoney = 0
        }
    },
    loc_txt = {
        ['name'] = 'john',
        ['text'] = {
            [1] = 'gain {X:money,C:white}x2.5${} at the end of round'
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
                return {
                    dollars = (G.GAME.dollars) * 1.5,
                    message = "LOL"
                }
        end
    end
}