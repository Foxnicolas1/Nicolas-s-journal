SMODS.Joker{ --sketchpad
    name = "sketchpad",
    key = "sketchpad",
    config = {
        extra = {
            active = 1,
            odds = 4,
            consumable_slots = 1
        }
    },
    loc_txt = {
        ['name'] = 'sketchpad',
        ['text'] = {
            [1] = 'buying something in a shot has a {C:green}#1# in #2#{} chance to gain a consumable slot',
            [2] = '{C:red}only works once{}',
            [3] = '{C:inactive}#3#{}'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {G.GAME.probabilities.normal, card.ability.extra.odds, card.ability.extra.active}}
    end,

    calculate = function(self, card, context)
        if context.buying_card and not context.blueprint then
            if (card.ability.extra.active or 0) == 1 then
                if pseudorandom('group_0_7bdf949b') < G.GAME.probabilities.normal / card.ability.extra.odds then
                        SMODS.calculate_effect({func = function()
                G.E_MANAGER:add_event(Event({func = function()
                    G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.consumable_slots
                    return true
                end }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "success", colour = G.C.GREEN})
                return true
            end}, card)
                        SMODS.calculate_effect({func = function()
                    card.ability.extra.active = 0
                    return true
                end}, card)
                    end
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.active = 1
                    return true
                end,
                    message = "reset"
                }
        end
    end
}