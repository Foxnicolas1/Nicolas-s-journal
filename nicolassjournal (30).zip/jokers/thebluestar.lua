SMODS.Joker{ --the blue star
    name = "the blue star",
    key = "thebluestar",
    config = {
        extra = {
            c_black_hole = 0
        }
    },
    loc_txt = {
        ['name'] = 'the blue star',
        ['text'] = {
            [1] = 'scored cards will create a black hole'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    cost = 25,
    rarity = "nicolass_mythical",
    blueprint_compat = true,
    eternal_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 5,
        y = 4
    },

    in_pool = function(self, args)
        return false
    end,

    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and not context.blueprint then
                local created_spectral = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_spectral = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local spectral_card = create_card('Spectral', G.consumeables, nil, nil, nil, nil, 'c_black_hole')
                            spectral_card:add_to_deck()
                            G.consumeables:emplace(spectral_card)
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    message = created_spectral and localize('k_plus_spectral') or nil
                }
        end
    end
}