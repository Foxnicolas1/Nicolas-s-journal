SMODS.Rarity {
    key = "mythical",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('fff393'),
    loc_txt = {
        name = "mythical"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}